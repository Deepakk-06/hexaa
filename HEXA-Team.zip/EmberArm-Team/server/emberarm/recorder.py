"""Episode recording.

Primary backend writes a real LeRobotDataset (observation.state, action, camera video, task).
If LeRobot's dataset API is unavailable, a plain-NPZ fallback keeps the data instead of losing it
(clearly NOT LeRobot format; convert later).
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np

from .kinematics import ARM_JOINTS

STATE_NAMES = [f"{n}.pos" for n in ARM_JOINTS] + ["gripper.pos"]


def _vec(d: dict) -> np.ndarray:
    return np.array([float(d[k]) for k in STATE_NAMES], dtype=np.float32)


class _LeRobotBackend:
    kind = "lerobot"

    def __init__(self, root: Path, repo_id: str, fps: int, cameras: dict[str, tuple[int, int]]) -> None:
        from lerobot.datasets.lerobot_dataset import LeRobotDataset

        features = {
            "observation.state": {"dtype": "float32", "shape": (len(STATE_NAMES),), "names": STATE_NAMES},
            "action": {"dtype": "float32", "shape": (len(STATE_NAMES),), "names": STATE_NAMES},
        }
        for name, (w, h) in cameras.items():
            features[f"observation.images.{name}"] = {"dtype": "video", "shape": (h, w, 3), "names": ["height", "width", "channels"]}
        self.cameras = list(cameras)
        if (root / "meta" / "info.json").exists():
            self.ds = LeRobotDataset(repo_id, root=root)  # resume: append episodes
        else:
            self.ds = LeRobotDataset.create(repo_id, fps=fps, features=features, root=root, robot_type="so101_follower", use_videos=bool(cameras))

    def add(self, obs: dict, action: dict, task: str) -> None:
        frame = {"observation.state": _vec(obs), "action": _vec(action), "task": task}
        for name in self.cameras:
            frame[f"observation.images.{name}"] = obs[name]
        self.ds.add_frame(frame)

    def save(self) -> None:
        self.ds.save_episode()

    def discard(self) -> None:
        if hasattr(self.ds, "clear_episode_buffer"):
            self.ds.clear_episode_buffer()

    def close(self) -> None:
        if hasattr(self.ds, "finalize"):
            self.ds.finalize()


class _NpzBackend:
    kind = "npz-fallback"

    def __init__(self, root: Path, *_a, **_k) -> None:
        self.root = root
        root.mkdir(parents=True, exist_ok=True)
        self.n = len(list(root.glob("episode_*.npz")))
        self._reset()

    def _reset(self) -> None:
        self.states, self.actions, self.t, self.task = [], [], [], ""

    def add(self, obs: dict, action: dict, task: str) -> None:
        self.states.append(_vec(obs)); self.actions.append(_vec(action)); self.t.append(time.time()); self.task = task

    def save(self) -> None:
        np.savez_compressed(self.root / f"episode_{self.n:06d}.npz", state=np.array(self.states), action=np.array(self.actions),
                            t=np.array(self.t), task=self.task, names=np.array(STATE_NAMES))
        self.n += 1
        self._reset()

    def discard(self) -> None:
        self._reset()

    def close(self) -> None:
        pass


class EpisodeRecorder:
    def __init__(self, root: Path, repo_id: str, fps: int, cameras: dict[str, tuple[int, int]] | None = None, force_fallback: bool = False) -> None:
        self.fps, self.frames, self.active, self.task = fps, 0, False, ""
        self.episodes = 0
        self.warning = None
        cameras = cameras or {}
        if force_fallback:
            self.backend = _NpzBackend(root)
        else:
            try:
                self.backend = _LeRobotBackend(root, repo_id, fps, cameras)
            except Exception as error:  # ImportError or a LeRobot API mismatch
                self.warning = f"LeRobot dataset backend unavailable ({type(error).__name__}: {error}). Recording to NPZ fallback in {root}."
                self.backend = _NpzBackend(root)
        (root).mkdir(parents=True, exist_ok=True)
        (root / "emberarm_recording.json").write_text(json.dumps({"fps": fps, "backend": self.backend.kind, "repo_id": repo_id}, indent=2))

    def start(self, task: str) -> None:
        if not self.active:
            self.active, self.frames, self.task = True, 0, task or "teleoperation"

    def add(self, obs: dict, action: dict) -> None:
        if self.active:
            self.backend.add(obs, action, self.task)
            self.frames += 1

    def stop(self, save: bool = True) -> int:
        """End the episode. Returns the number of frames saved (0 if discarded or empty)."""
        if not self.active:
            return 0
        self.active = False
        if save and self.frames > 0:
            self.backend.save()
            self.episodes += 1
            return self.frames
        self.backend.discard()
        return 0

    def close(self) -> None:
        self.stop(save=True)
        self.backend.close()
