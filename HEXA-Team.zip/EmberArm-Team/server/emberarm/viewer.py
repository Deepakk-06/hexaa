"""Tiny browser viewer for the simulated arm. Open http://localhost:8080 (stdlib + numpy only)."""
from __future__ import annotations

import json
import math
import threading
import xml.etree.ElementTree as ET
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import numpy as np

PORT = 8080


def _vec(s, default=0.0):
    return [float(x) for x in s.split()] if s else [default] * 3


def _origin(xyz, rpy):
    r, p, y = rpy
    cr, sr, cp, sp, cy, sy = math.cos(r), math.sin(r), math.cos(p), math.sin(p), math.cos(y), math.sin(y)
    Rx = np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]])
    Ry = np.array([[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]])
    Rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]])
    M = np.eye(4)
    M[:3, :3] = Rz @ Ry @ Rx
    M[:3, 3] = xyz
    return M


def _axis_rot(axis, angle):
    a = np.array(axis, dtype=float)
    n = np.linalg.norm(a)
    a = a / n if n else np.array([0.0, 0.0, 1.0])
    x, y, z = a
    c, s = math.cos(angle), math.sin(angle)
    C = 1 - c
    M = np.eye(4)
    M[:3, :3] = [[c + x * x * C, x * y * C - z * s, x * z * C + y * s],
                 [y * x * C + z * s, c + y * y * C, y * z * C - x * s],
                 [z * x * C - y * s, z * y * C + x * s, c + z * z * C]]
    return M


class Urdf:
    def __init__(self, path) -> None:
        root = ET.parse(str(path)).getroot()
        self.joints = []
        for j in root.findall("joint"):
            o, a, lim = j.find("origin"), j.find("axis"), j.find("limit")
            self.joints.append({
                "name": j.get("name"), "type": j.get("type"),
                "parent": j.find("parent").get("link"), "child": j.find("child").get("link"),
                "origin": _origin(_vec(o.get("xyz") if o is not None else None), _vec(o.get("rpy") if o is not None else None)),
                "axis": _vec(a.get("xyz") if a is not None else "0 0 1"),
                "lo": float(lim.get("lower", -1.5)) if lim is not None else -1.5,
                "hi": float(lim.get("upper", 1.5)) if lim is not None else 1.5,
            })
        mats = {}
        for m in root.findall("material"):
            c = m.find("color")
            if m.get("name") and c is not None and c.get("rgba"):
                mats[m.get("name")] = [float(x) for x in c.get("rgba").split()]
        self.visuals = {}
        for l in root.findall("link"):
            vis = []
            for v in l.findall("visual"):
                mesh = v.find("geometry/mesh")
                if mesh is None or not mesh.get("filename"):
                    continue
                o = v.find("origin")
                mat = v.find("material")
                rgba = mats.get(mat.get("name")) if mat is not None else None
                if rgba is None and mat is not None and mat.find("color") is not None:
                    rgba = [float(x) for x in mat.find("color").get("rgba").split()]
                vis.append({
                    "mesh": Path(mesh.get("filename")).name,
                    "m": [float(x) for x in _origin(_vec(o.get("xyz") if o is not None else None),
                                                    _vec(o.get("rpy") if o is not None else None)).flatten()],
                    "color": (rgba or [0.8, 0.8, 0.8, 1.0])[:3],
                })
            self.visuals[l.get("name")] = vis
        children = {j["child"] for j in self.joints}
        self.root = next(l.get("name") for l in root.findall("link") if l.get("name") not in children)
        self.edges = [[j["parent"], j["child"]] for j in self.joints]
        self.movable = [j for j in self.joints if j["type"] in ("revolute", "continuous", "prismatic")]

    def fk(self, q: dict) -> dict:
        T = {self.root: np.eye(4)}
        pending = list(self.joints)
        while pending:
            rest = []
            for j in pending:
                if j["parent"] not in T:
                    rest.append(j)
                    continue
                M = T[j["parent"]] @ j["origin"]
                v = q.get(j["name"], 0.0)
                if j["type"] in ("revolute", "continuous"):
                    M = M @ _axis_rot(j["axis"], v)
                elif j["type"] == "prismatic":
                    S = np.eye(4)
                    S[:3, 3] = np.array(j["axis"]) * v
                    M = M @ S
                T[j["child"]] = M
            if len(rest) == len(pending):
                break
            pending = rest
        return {k: [float(x) for x in m[:3, 3]] for k, m in T.items()}


    def describe(self) -> dict:
        return {
            "root": self.root,
            "links": self.visuals,
            "joints": [{
                "name": j["name"], "type": j["type"], "parent": j["parent"], "child": j["child"],
                "m": [float(x) for x in j["origin"].flatten()], "axis": j["axis"],
                "lo": j["lo"], "hi": j["hi"],
            } for j in self.joints],
        }


PAGE = r"""<!doctype html><meta charset=utf-8><title>EmberArm viewer</title>
<style>body{margin:0;background:#15171a;color:#ddd;font:13px monospace;overflow:hidden}
#t{position:fixed;left:12px;top:12px;white-space:pre;line-height:1.5;pointer-events:none;text-shadow:0 0 4px #000}</style>
<div id=t>loading arm...</div>
<script type="importmap">{"imports":{"three":"https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js","three/addons/":"https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/"}}</script>
<script type="module">
import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {STLLoader} from 'three/addons/loaders/STLLoader.js';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';
const t = document.getElementById('t');
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x15171a);
const camera = new THREE.PerspectiveCamera(45, innerWidth / innerHeight, 0.01, 10);
camera.up.set(0, 0, 1);
camera.position.set(0.5, -0.5, 0.35);
const renderer = new THREE.WebGLRenderer({antialias: true});
renderer.setPixelRatio(devicePixelRatio);
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.0;
document.body.appendChild(renderer.domElement);
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 0, 0.18);
controls.update();
scene.environment = new THREE.PMREMGenerator(renderer).fromScene(new RoomEnvironment(), 0.04).texture;
scene.background = new THREE.Color(0x20242a);
scene.add(new THREE.HemisphereLight(0xffffff, 0x554433, 0.35));
const sun = new THREE.DirectionalLight(0xfff2e0, 2.4);
sun.position.set(0.5, -0.4, 1.1); sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048);
Object.assign(sun.shadow.camera, {left: -0.5, right: 0.5, top: 0.5, bottom: -0.5, near: 0.1, far: 3}); sun.shadow.bias = -0.0004;
scene.add(sun);
addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});


// ---------- realistic pick-and-place scene ----------
const Z = new THREE.Vector3(0, 0, 1);
function rnd(seed) { let x = seed; return () => (x = (x * 16807) % 2147483647) / 2147483647; }
function ctex(w, h, draw, rep) {
  const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  if (rep) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rep[0], rep[1]); }
  return t;
}
function noise(g, w, h, n, r, a) { for (let i = 0; i < n; i++) { g.fillStyle = r() > 0.5 ? `rgba(255,255,255,${a})` : `rgba(0,0,0,${a})`; g.fillRect(r() * w, r() * h, 1 + r() * 2, 1 + r() * 2); } }
const kraft = (label, tape, seed) => ctex(256, 256, (g, w, h) => {
  const r = rnd(seed); g.fillStyle = '#b98d58'; g.fillRect(0, 0, w, h);
  for (let y = 0; y < h; y += 5) { g.fillStyle = 'rgba(90,60,25,0.07)'; g.fillRect(0, y, w, 2); }
  noise(g, w, h, 5000, r, 0.05);
  if (tape) { g.fillStyle = 'rgba(214,180,120,0.92)'; g.fillRect(0, h * 0.4, w, h * 0.2); g.fillStyle = 'rgba(255,255,255,0.14)'; g.fillRect(0, h * 0.42, w, 4); g.fillStyle = 'rgba(60,40,15,0.35)'; g.fillRect(0, h * 0.4, w, 1); g.fillRect(0, h * 0.6, w, 1); }
  if (label) { g.fillStyle = '#f2f0ea'; g.fillRect(w * 0.18, h * 0.22, w * 0.5, h * 0.42); g.fillStyle = '#444'; for (let i = 0; i < 4; i++) g.fillRect(w * 0.22, h * (0.27 + i * 0.05), w * (0.28 + 0.1 * r()), 4); for (let i = 0; i < 28; i++) g.fillRect(w * 0.22 + i * 4.4, h * 0.5, 1 + 2 * r(), h * 0.1); }
}, null);
const woodTex = () => ctex(1024, 1024, (g, w, h) => {
  const r = rnd(7); const n = 10, ph = h / n;
  for (let i = 0; i < n; i++) { const l = 52 + r() * 8; g.fillStyle = `hsl(28,38%,${l}%)`; g.fillRect(0, i * ph, w, ph);
    for (let k = 0; k < 90; k++) { g.strokeStyle = `rgba(70,40,15,${0.04 + r() * 0.09})`; g.lineWidth = 0.5 + r() * 1.5; const y = i * ph + r() * ph; g.beginPath(); g.moveTo(0, y); g.bezierCurveTo(w * 0.3, y + r() * 5 - 2.5, w * 0.6, y + r() * 5 - 2.5, w, y + r() * 4 - 2); g.stroke(); }
    g.fillStyle = 'rgba(30,15,5,0.55)'; g.fillRect(0, i * ph, w, 2); }
}, [2, 2]);
const appleSkin = () => ctex(512, 256, (g, w, h) => {
  const r = rnd(11); g.fillStyle = '#a51d1d'; g.fillRect(0, 0, w, h);
  const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, 'rgba(205,190,60,0.85)'); gr.addColorStop(0.16, 'rgba(205,190,60,0)'); gr.addColorStop(0.84, 'rgba(205,190,60,0)'); gr.addColorStop(1, 'rgba(205,190,60,0.7)'); g.fillStyle = gr; g.fillRect(0, 0, w, h);
  for (let i = 0; i < 300; i++) { const x = r() * w, y = r() * h * 0.6, l = 40 + r() * 140; g.strokeStyle = r() > 0.5 ? 'rgba(110,0,0,0.22)' : 'rgba(235,90,50,0.18)'; g.lineWidth = 1 + r() * 3; g.beginPath(); g.moveTo(x, y); g.lineTo(x + r() * 6 - 3, y + l); g.stroke(); }
  for (let i = 0; i < 160; i++) { g.fillStyle = 'rgba(245,225,170,0.55)'; g.beginPath(); g.arc(r() * w, h * (0.12 + 0.76 * r()), 0.7 + r() * 1.2, 0, 7); g.fill(); }
  noise(g, w, h, 6000, r, 0.04);
}, null);
function appleGeo() {
  const H = 0.068, W = 0.074, pts = [];
  for (let i = 0; i <= 48; i++) { const th = Math.PI * (1 - i / 48);
    const y = Math.cos(th) * H / 2 - 0.011 * Math.exp(-((th / 0.38) ** 2)) + 0.006 * Math.exp(-(((Math.PI - th) / 0.42) ** 2));
    pts.push(new THREE.Vector2(Math.max(Math.sin(th) * W / 2 * (1 + 0.14 * Math.cos(th)), 0.0001), y)); }
  const g = new THREE.LatheGeometry(pts, 64); g.rotateX(Math.PI / 2); g.computeVertexNormals(); return g;
}
const skin = appleSkin();
function makeApple() {
  const g = new THREE.Group();
  g.add(new THREE.Mesh(appleGeo(), new THREE.MeshPhysicalMaterial({map: skin, roughness: 0.38, clearcoat: 0.5, clearcoatRoughness: 0.28})));
  const curve = new THREE.CatmullRomCurve3([new THREE.Vector3(0, 0, 0.017), new THREE.Vector3(0.001, 0, 0.03), new THREE.Vector3(0.006, 0.001, 0.043)]);
  g.add(new THREE.Mesh(new THREE.TubeGeometry(curve, 8, 0.0017, 6), new THREE.MeshStandardMaterial({color: 0x4e342e, roughness: 0.9})));
  const sh = new THREE.Shape(); sh.moveTo(0, 0); sh.quadraticCurveTo(0.012, 0.009, 0.03, 0); sh.quadraticCurveTo(0.012, -0.009, 0, 0);
  const leaf = new THREE.Mesh(new THREE.ShapeGeometry(sh), new THREE.MeshStandardMaterial({color: 0x3f7d2c, roughness: 0.6, side: THREE.DoubleSide}));
  leaf.position.set(0.006, 0.001, 0.038); leaf.rotation.set(0.25, 0.45, 0.7); g.add(leaf);
  return g;
}
function makeBox(sx, sy, sz, label, seed) {
  const side = new THREE.MeshStandardMaterial({map: kraft(label, false, seed), roughness: 0.95}), top = new THREE.MeshStandardMaterial({map: kraft(false, true, seed + 1), roughness: 0.9}), bot = new THREE.MeshStandardMaterial({color: 0x9a7448, roughness: 1});
  return new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), [side, side, side, side, top, bot]);
}
const objs = [], shade = o => o.traverse(m => { if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; } });
const BIN = {x: 0.20, y: 0.13, hw: 0.05};
function groundZ(x, y) { return (Math.abs(x - BIN.x) < BIN.hw - 0.006 && Math.abs(y - BIN.y) < BIN.hw - 0.006) ? 0.006 : 0; }
const floor = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), new THREE.MeshStandardMaterial({map: woodTex(), roughness: 0.75}));
floor.position.z = -0.0005; floor.receiveShadow = true; scene.add(floor);
(function makeBin() {
  const g = new THREE.Group(), t = 0.005, h = 0.032, w = BIN.hw * 2, m = new THREE.MeshStandardMaterial({map: kraft(false, false, 31), roughness: 0.95});
  const base = new THREE.Mesh(new THREE.BoxGeometry(w, w, 0.006), m); base.position.z = 0.003; g.add(base);
  for (const [dx, dy, sx, sy] of [[BIN.hw, 0, t, w], [-BIN.hw, 0, t, w], [0, BIN.hw, w, t], [0, -BIN.hw, w, t]]) { const wall = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, h), m); wall.position.set(dx, dy, h / 2); g.add(wall); }
  g.position.set(BIN.x, BIN.y, 0); shade(g); scene.add(g);
})();
const SPAWN = [['apple', 0.22, -0.08, 0.034, 0.036], ['box A', 0.16, -0.05, 0.0175, 0.032, [0.055, 0.04, 0.035], true], ['box B', 0.27, -0.01, 0.0225, 0.034, [0.045, 0.045, 0.045], false], ['box C', 0.17, 0.03, 0.015, 0.032, [0.06, 0.035, 0.03], true]];
function spawn() {
  for (const o of objs) o.mesh.parent.remove(o.mesh);
  objs.length = 0;
  SPAWN.forEach(([name, x, y, h, r, d, lab], i) => {
    const mesh = name === 'apple' ? makeApple() : makeBox(d[0], d[1], d[2], lab, 100 + i * 7);
    mesh.position.set(x, y, h); if (name !== 'apple') mesh.rotation.z = (i - 2) * 0.35;
    shade(mesh); scene.add(mesh); objs.push({name, mesh, h, r, vz: 0, held: false});
  });
}
spawn();
addEventListener('keydown', e => { if (e.key === 'r' || e.key === 'R') spawn(); });
const tmp = new THREE.Vector3(), tool = new THREE.Vector3(), va = new THREE.Vector3(), vb = new THREE.Vector3(), vc = new THREE.Vector3(), vd = new THREE.Vector3();
let SEGS = [], openSeen = true;
function physics(dt, grip) {
  const tf = LG && LG['gripper_frame_link'];
  if (tf) tf.getWorldPosition(tool);
  if (grip !== undefined && grip > 45) openSeen = true;   // must open first, then close = a deliberate grasp
  for (const o of objs) {
    const p = o.mesh.position;
    if (tf && grip !== undefined) {
      if (!o.held && openSeen && grip < 30 && !objs.some(q => q.held) && o.mesh.getWorldPosition(tmp).distanceTo(tool) < 0.035) { tf.attach(o.mesh); o.held = true; openSeen = false; }
      else if (o.held && grip > 40) { scene.attach(o.mesh); o.held = false; o.vz = 0; o.mesh.quaternion.setFromAxisAngle(Z, Math.atan2(o.mesh.matrixWorld.elements[1], o.mesh.matrixWorld.elements[0])); }
    }
    if (o.held) continue;
    for (const [pa, pb] of SEGS) {   // arm links push loose objects aside instead of sticking to them
      LG[pa].getWorldPosition(va); LG[pb].getWorldPosition(vb); vc.subVectors(vb, va);
      const t = Math.max(0, Math.min(1, vd.subVectors(p, va).dot(vc) / (vc.lengthSq() || 1)));
      vd.copy(va).addScaledVector(vc, t); vd.subVectors(p, vd);
      const dist = vd.length(), min = 0.028 + o.r;
      if (dist < min && dist > 1e-6) { vd.multiplyScalar((min - dist) / dist); p.x += vd.x; p.y += vd.y; p.z += Math.max(vd.z, 0); }
    }
    o.vz -= 9.8 * dt; p.z += o.vz * dt;
    const gz = groundZ(p.x, p.y) + o.h;
    if (p.z < gz) { p.z = gz; o.vz = 0; }
  }
}
function sceneText() {
  const inBin = objs.filter(o => !o.held && groundZ(o.mesh.position.x, o.mesh.position.y) > 0).length;
  const held = objs.find(o => o.held);
  return '\n\nin bin: ' + inBin + '/' + objs.length + (held ? '   holding: ' + held.name : '') + '\nopen gripper, close it around an object to grab; open to drop; R = reset';
}

const ARM_COLOR = 0xe8431a;   // red-orange printed parts; change this hex to recolor the arm
function armMat(file) {
  const f = file.toLowerCase();
  if (f.includes('sts3215')) return new THREE.MeshStandardMaterial({color: 0x1c1c1e, roughness: 0.5, metalness: 0.1});   // servos: black
  if (f.includes('waveshare')) return new THREE.MeshStandardMaterial({color: 0x2a2a2d, roughness: 0.6});
  return new THREE.MeshPhysicalMaterial({color: ARM_COLOR, roughness: 0.42, clearcoat: 0.3, clearcoatRoughness: 0.35});   // 3D-printed plastic
}
const M4 = a => new THREE.Matrix4().set(...a);   // server sends row-major
const motion = {};      // joint name -> {group, joint}
let failed = [];
let LG = null;

async function build() {
  const d = await (await fetch('/urdf', {cache: 'no-store'})).json();
  const loader = new STLLoader();
  const geoCache = {};
  const loadGeo = file => geoCache[file] ||= new Promise(res => loader.load('/assets/' + file, g => {
    g.computeBoundingBox();
    const s = g.boundingBox.getSize(new THREE.Vector3());
    if (Math.max(s.x, s.y, s.z) > 2) g.scale(0.001, 0.001, 0.001);   // STL in mm -> m
    g.computeVertexNormals();
    res(g);
  }, undefined, () => { failed.push(file); res(null); }));

  const linkGroups = {};
  for (const name of Object.keys(d.links)) linkGroups[name] = new THREE.Group();
  for (const [name, vis] of Object.entries(d.links)) {
    for (const v of vis) {
      loadGeo(v.mesh).then(g => {
        if (!g) return;
        const mesh = new THREE.Mesh(g, armMat(v.mesh));
        mesh.matrixAutoUpdate = false; mesh.castShadow = true; mesh.receiveShadow = true;
        mesh.matrix.copy(M4(v.m));
        linkGroups[name].add(mesh);
      });
    }
  }
  for (const j of d.joints) {
    const frame = new THREE.Group();
    frame.matrixAutoUpdate = false;
    frame.matrix.copy(M4(j.m));
    const mot = new THREE.Group();
    frame.add(mot);
    mot.add(linkGroups[j.child]);
    linkGroups[j.parent].add(frame);
    motion[j.name] = {group: mot, type: j.type, axis: new THREE.Vector3(...j.axis).normalize()};
  }
  LG = linkGroups;
  SEGS = d.joints.filter(j => ['elbow_flex', 'wrist_flex', 'wrist_roll'].includes(j.name)).map(j => [j.parent, j.child]);
  scene.add(linkGroups[d.root]);
  await Promise.all(Object.values(geoCache));
}

function apply(q) {
  for (const [name, v] of Object.entries(q)) {
    const m = motion[name];
    if (!m) continue;
    if (m.type === 'prismatic') m.group.position.copy(m.axis).multiplyScalar(v);
    else if (m.type === 'revolute' || m.type === 'continuous') m.group.quaternion.setFromAxisAngle(m.axis, v);
  }
}

let status = {mode: '?', joints: {}, note: ''};
const target = {}, cur = {};          // joint targets from the server / what is drawn
async function poll() {
  try {
    const S = await (await fetch('/state', {cache: 'no-store'})).json();
    for (const [k, v] of Object.entries(S.q || {})) { target[k] = v; if (!(k in cur)) cur[k] = v; }
    status = S;
  } catch (e) { status = {mode: 'waiting for server...', joints: {}, note: ''}; }
  setTimeout(poll, 15);
}
let last = performance.now();
function loop(now) {
  requestAnimationFrame(loop);
  const dt = Math.min((now - last) / 1000, 0.1); last = now;
  const k = 1 - Math.exp(-dt / 0.04);   // 40 ms smoothing: hides network stair-steps, adds almost no lag
  for (const n in target) cur[n] += (target[n] - cur[n]) * k;
  apply(cur);
  physics(dt, status.joints ? status.joints.gripper : undefined);
  controls.update();
  renderer.render(scene, camera);
  t.textContent = 'mode: ' + status.mode + '   (drag = rotate, wheel = zoom, right-drag = pan)\n' +
    Object.entries(status.joints || {}).map(([n, v]) => n.padEnd(14) + v.toFixed(1)).join('\n') +
    (status.note ? '\n\n' + status.note : '') + sceneText() +
    (failed.length ? '\n\nmissing meshes: ' + [...new Set(failed)].join(', ') : '');
}
build().then(() => { poll(); requestAnimationFrame(loop); }).catch(e => { t.textContent = 'viewer failed: ' + e; });
</script>"""


def start_viewer(host, port: int = PORT) -> None:
    urdf_path = Path(host.args.urdf)
    urdf = Urdf(urdf_path)
    assets_dir = urdf_path.parent / "assets"
    describe = json.dumps(urdf.describe()).encode()

    def state() -> dict:
        obs, note = {}, ""
        try:
            if host.robot is not None:
                obs = host.robot.get_observation()
        except Exception as error:
            note = f"get_observation failed: {error}"
        scalars = {}
        try:
            for k, v in dict(obs).items():
                try:
                    scalars[str(k)] = float(v)
                except Exception:
                    pass
        except Exception:
            pass
        q, shown = {}, {}
        for j in urdf.movable:
            name = j["name"]
            for key in (name, name + ".pos"):
                if key in scalars:
                    v = scalars[key]
                    shown[name] = v
                    q[name] = (j["lo"] + (j["hi"] - j["lo"]) * v / 100.0) if name == "gripper" else math.radians(v)
                    break
        if not q and not note:
            note = "No joint values found. Observation keys: " + (", ".join(list(scalars)[:12]) or "(none)")
        return {"mode": host.mode, "q": q, "joints": shown, "note": note}

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"   # keep-alive: no new connection per poll
        wbufsize = 65536                # headers + body leave in one write
        disable_nagle_algorithm = True  # no 40 ms delayed-ACK stalls

        def _send(self, code, body, ctype):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            path = self.path.split("?")[0]
            if path == "/state":
                self._send(200, json.dumps(state()).encode(), "application/json")
            elif path == "/urdf":
                self._send(200, describe, "application/json")
            elif path.startswith("/assets/"):
                f = assets_dir / Path(path[len("/assets/"):]).name   # no path traversal
                if f.suffix.lower() == ".stl" and f.is_file():
                    self._send(200, f.read_bytes(), "application/octet-stream")
                else:
                    self._send(404, b"missing mesh", "text/plain")
            else:
                self._send(200, PAGE.encode(), "text/html; charset=utf-8")

        def log_message(self, *args):
            pass

    srv = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    missing = sorted({v["mesh"] for vis in urdf.visuals.values() for v in vis if not (assets_dir / v["mesh"]).is_file()})
    if missing:
        print(f"Arm viewer: {len(missing)} mesh file(s) missing in {assets_dir}: {', '.join(missing)}")
    print(f"Arm viewer:  http://localhost:{port}")
