"""Math helpers and SO-101 forward/inverse kinematics (from the official URDF)."""
from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np

ARM_JOINTS = ("shoulder_pan", "shoulder_lift", "elbow_flex", "wrist_flex", "wrist_roll")
SEED_DEG = np.array([0.0, -56.0, 34.0, 58.0, 0.0])  # starting pose for dry run / sim


# ----------------------------------------------------------------------------- math
def rot_rpy(r: float, p: float, y: float) -> np.ndarray:
    cr, sr, cp, sp, cy, sy = np.cos(r), np.sin(r), np.cos(p), np.sin(p), np.cos(y), np.sin(y)
    return np.array([
        [cy * cp, cy * sp * sr - sy * cr, cy * sp * cr + sy * sr],
        [sy * cp, sy * sp * sr + cy * cr, sy * sp * cr - cy * sr],
        [-sp, cp * sr, cp * cr],
    ])


def rot_axis(axis: np.ndarray, angle: float) -> np.ndarray:
    x, y, z = axis
    c, s = np.cos(angle), np.sin(angle)
    k = 1 - c
    return np.array([
        [c + x * x * k, x * y * k - z * s, x * z * k + y * s],
        [y * x * k + z * s, c + y * y * k, y * z * k - x * s],
        [z * x * k - y * s, z * y * k + x * s, c + z * z * k],
    ])


def quat_to_rot(q: dict) -> np.ndarray:
    x, y, z, w = (float(q[k]) for k in ("x", "y", "z", "w"))
    n = np.sqrt(x * x + y * y + z * z + w * w) or 1.0
    x, y, z, w = x / n, y / n, z / n, w / n
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ])


def rotvec(R: np.ndarray) -> np.ndarray:
    """Rotation matrix -> axis*angle vector."""
    cos = np.clip((np.trace(R) - 1) / 2, -1.0, 1.0)
    angle = float(np.arccos(cos))
    if angle < 1e-8:
        return np.zeros(3)
    axis = np.array([R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1]])
    norm = np.linalg.norm(axis)
    if norm < 1e-8:  # 180 degrees: pick the axis from the diagonal
        axis = np.sqrt(np.maximum((np.diag(R) + 1) / 2, 0))
        return axis / (np.linalg.norm(axis) or 1.0) * angle
    return axis / norm * angle


def wrap(a: float) -> float:
    return (a + np.pi) % (2 * np.pi) - np.pi


# ----------------------------------------------------------------------------- kinematics
class SO101Kinematics:
    """Forward kinematics and damped-least-squares IK straight from the SO-101 URDF."""

    PITCH_WEIGHT = 0.12  # metres of position error one radian of pitch error is worth

    def __init__(self, urdf_path: Path) -> None:
        root = ET.parse(urdf_path).getroot()
        by_child = {j.find("child").get("link"): j for j in root.findall("joint")}
        chain, link = [], "gripper_frame_link"
        while link in by_child:
            joint = by_child[link]
            chain.append(joint)
            link = joint.find("parent").get("link")
        chain.reverse()
        self.links: list[tuple[np.ndarray, np.ndarray | None, str]] = []
        lows, highs = [], []
        for joint in chain:
            origin = joint.find("origin")
            xyz = [float(v) for v in origin.get("xyz").split()]
            rpy = [float(v) for v in origin.get("rpy").split()]
            t0 = np.eye(4)
            t0[:3, :3] = rot_rpy(*rpy)
            t0[:3, 3] = xyz
            axis = None
            if joint.get("type") == "revolute":
                axis = np.array([float(v) for v in joint.find("axis").get("xyz").split()])
                limit = joint.find("limit")
                lows.append(float(limit.get("lower")))
                highs.append(float(limit.get("upper")))
            self.links.append((t0, axis, joint.get("name")))
        names = [n for _, a, n in self.links if a is not None]
        if tuple(names) != ARM_JOINTS:
            raise RuntimeError(f"Unexpected URDF joint chain: {names}")
        self.low = np.array(lows)
        self.high = np.array(highs)

    def fk(self, q: np.ndarray) -> tuple[np.ndarray, float]:
        """q: 5 joint angles (rad). Returns tip position (3,) and tool pitch (rad)."""
        T = np.eye(4)
        k = 0
        wrist = np.zeros(3)
        for t0, axis, name in self.links:
            T = T @ t0
            if axis is not None:
                r = np.eye(4)
                r[:3, :3] = rot_axis(axis, q[k])
                T = T @ r
                k += 1
            if name == "wrist_roll":
                wrist = T[:3, 3].copy()
        tip = T[:3, 3].copy()
        v = tip - wrist
        pitch = float(np.arctan2(v[2], np.hypot(v[0], v[1])))
        return tip, pitch

    def _task(self, q4: np.ndarray, roll: float) -> np.ndarray:
        tip, pitch = self.fk(np.append(q4, roll))
        return np.array([*tip, pitch])

    def ik(self, tip: np.ndarray, pitch: float, q_seed: np.ndarray) -> tuple[np.ndarray, float]:
        """Solve pan/lift/elbow/wrist_flex for a tip position + tool pitch. Roll is kept as is.
        Returns the 5-joint solution (rad) and the remaining position error (m)."""
        q4 = np.clip(q_seed[:4].copy(), self.low[:4], self.high[:4])
        roll = float(q_seed[4])
        w = self.PITCH_WEIGHT
        lam = 0.02
        for _ in range(80):
            cur = self._task(q4, roll)
            err = np.array([*(tip - cur[:3]), w * wrap(pitch - cur[3])])
            if np.linalg.norm(err[:3]) < 1e-4 and abs(err[3]) < w * 2e-3:
                break
            jac = np.zeros((4, 4))
            for i in range(4):
                d = np.zeros(4)
                d[i] = 1e-5
                diff = self._task(q4 + d, roll) - cur
                diff[3] = wrap(diff[3])
                jac[:, i] = (diff * np.array([1, 1, 1, w])) / 1e-5
            step = jac.T @ np.linalg.solve(jac @ jac.T + lam**2 * np.eye(4), err)
            q4 = np.clip(q4 + np.clip(step, -0.15, 0.15), self.low[:4], self.high[:4])
        cur = self._task(q4, roll)
        return np.append(q4, roll), float(np.linalg.norm(tip - cur[:3]))
