"""Robot backends behind one small interface.

  get_observation() -> {"<joint>.pos": deg, ..., "gripper.pos": 0-100, "<camera>": HxWx3 array}
  send_action({"<joint>.pos": deg, ..., "gripper.pos": 0-100})
  disconnect()

Backends: SimRobot (no hardware), LeRobotRobot (real SO-101). Dry run uses no backend (robot=None).
"""
from __future__ import annotations

import time

import numpy as np

from .kinematics import ARM_JOINTS, SEED_DEG

ALL_KEYS = [f"{n}.pos" for n in ARM_JOINTS] + ["gripper.pos"]


class SimRobot:
    """Fake follower that tracks commanded joints with a speed limit. Lets you test and record with no hardware."""

    is_sim = True

    def __init__(self, max_deg_per_s: float = 120.0) -> None:
        self.state = {f"{n}.pos": float(v) for n, v in zip(ARM_JOINTS, SEED_DEG)}
        self.state["gripper.pos"] = 50.0
        self.max_rate = max_deg_per_s
        self._t = time.monotonic()
        self.connected = True

    def _advance(self, target: dict | None) -> None:
        now = time.monotonic()
        dt = min(now - self._t, 0.2)
        self._t = now
        if target:
            for k in ALL_KEYS:
                if k in target:
                    step = self.max_rate * dt
                    self.state[k] += float(np.clip(target[k] - self.state[k], -step, step))

    def get_observation(self) -> dict:
        self._advance(None)
        return dict(self.state)

    def send_action(self, action: dict) -> dict:
        self._advance(action)
        return action

    def disconnect(self) -> None:
        self.connected = False


class LeRobotRobot:
    """Thin wrapper over LeRobot's SO-101 follower. All LeRobot imports live here so version changes stay local."""

    is_sim = False

    def __init__(self, port: str, robot_id: str, max_step_deg: float, cameras: dict[str, int] | None = None,
                 cam_size: tuple[int, int] = (640, 480), cam_fps: int = 30) -> None:
        try:
            from lerobot.robots.so101_follower import SO101Follower, SO101FollowerConfig
        except ImportError:
            try:
                from lerobot.robots.so100_follower import SO100Follower as SO101Follower
                from lerobot.robots.so100_follower import SO100FollowerConfig as SO101FollowerConfig
            except ImportError as error:
                raise RuntimeError('LeRobot is not installed. Run:  emberarm setup  (or: pip install "lerobot[feetech]")') from error
        kwargs = {}
        if cameras:
            from lerobot.cameras.opencv.configuration_opencv import OpenCVCameraConfig

            kwargs["cameras"] = {name: OpenCVCameraConfig(index_or_path=idx, width=cam_size[0], height=cam_size[1], fps=cam_fps)
                                 for name, idx in cameras.items()}
        config = SO101FollowerConfig(port=port, id=robot_id, use_degrees=True, max_relative_target=max_step_deg, **kwargs)
        self.robot = SO101Follower(config)
        self.camera_names = list(cameras or {})
        try:
            self.robot.connect(calibrate=False)  # never block a server on an interactive calibration prompt
        except TypeError:
            self.robot.connect()
        if getattr(self.robot, "is_calibrated", True) is False:
            self.robot.disconnect()
            raise RuntimeError(f"Robot id '{robot_id}' has no calibration. Run:  emberarm calibrate  first.")

    def get_observation(self) -> dict:
        return self.robot.get_observation()

    def send_action(self, action: dict) -> dict:
        return self.robot.send_action(action)

    def disconnect(self) -> None:
        # LeRobot turns motor torque off here, so the arm goes limp. Park it somewhere safe first.
        self.robot.disconnect()
