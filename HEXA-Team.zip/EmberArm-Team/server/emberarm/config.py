"""Small JSON config (emberarm.json next to the server) so settings survive between runs and machines."""
from __future__ import annotations

import json
from pathlib import Path

CONFIG_PATH = Path(__file__).resolve().parent.parent / "emberarm.json"
DEFAULTS = {"robot_id": "my_awesome_follower_arm", "arm_port": None, "ws_port": 4443, "scale": 1.0, "max_speed": 45.0,
            "roll_sign": 1.0, "invert_gripper": False, "fps": 30, "dataset_dir": "datasets/emberarm_demo",
            "repo_id": "local/emberarm_demo", "task": "teleoperation", "cameras": {}}


def load() -> dict:
    cfg = dict(DEFAULTS)
    if CONFIG_PATH.exists():
        try:
            cfg.update(json.loads(CONFIG_PATH.read_text()))
        except json.JSONDecodeError:
            print(f"Warning: {CONFIG_PATH} is not valid JSON; using defaults.")
    return cfg


def save(cfg: dict) -> None:
    CONFIG_PATH.write_text(json.dumps(cfg, indent=2) + "\n")
