"""Phone pose -> SO-101 joint targets, with dead-man handling and speed limits."""
from __future__ import annotations

import math
import os
import time
from pathlib import Path

import numpy as np

from .kinematics import ARM_JOINTS, SEED_DEG, SO101Kinematics, quat_to_rot, rotvec

ENGAGE_GAP_S = 0.25  # no control message for this long = pad was released

# Smoothing of the phone pose (ARCore is noisy at the millimetre level). Set EMBERARM_SMOOTH=0 to turn it off.
SMOOTH_DEFAULT = os.environ.get("EMBERARM_SMOOTH", "1") != "0"
SMOOTH_POS = (1.0, 10.0)   # (min_cutoff Hz, beta): still-hand smoothing, how quickly it opens up when moving
SMOOTH_ROT = (1.5, 2.0)


class OneEuro:
    """Speed-adaptive low-pass filter (One Euro, Casiez et al. 2012).
    Heavy smoothing when the hand is slow or still (kills jitter), light smoothing when it moves fast (little lag)."""

    def __init__(self, min_cutoff: float, beta: float, d_cutoff: float = 1.0) -> None:
        self.min_cutoff, self.beta, self.d_cutoff = min_cutoff, beta, d_cutoff
        self.reset()

    def reset(self) -> None:
        self.x: np.ndarray | None = None
        self.dx = np.zeros(3)

    @staticmethod
    def _alpha(cutoff: float, dt: float) -> float:
        tau = 1.0 / (2.0 * math.pi * cutoff)
        return 1.0 / (1.0 + tau / dt)

    def __call__(self, x: np.ndarray, dt: float) -> np.ndarray:
        if self.x is None:
            self.x = np.array(x, dtype=float)
            return self.x.copy()
        dt = max(dt, 1e-3)
        dx = (x - self.x) / dt
        a_d = self._alpha(self.d_cutoff, dt)
        self.dx = a_d * dx + (1 - a_d) * self.dx
        cutoff = self.min_cutoff + self.beta * float(np.linalg.norm(self.dx))
        a = self._alpha(cutoff, dt)
        self.x = a * x + (1 - a) * self.x
        return self.x.copy()


def validate_pose(pose: dict) -> None:
    """Reject malformed or non-finite poses before they reach the IK."""
    try:
        values = [float(pose["position"][k]) for k in "xyz"] + [float(pose["rotation"][k]) for k in "xyzw"]
    except (KeyError, TypeError) as error:
        raise ValueError("Malformed pose from phone.") from error
    if not all(math.isfinite(v) for v in values):
        raise ValueError("Pose contains NaN/inf.")
    if abs(values[0]) > 50 or abs(values[1]) > 50 or abs(values[2]) > 50:
        raise ValueError("Pose position is implausibly far away; tracking probably glitched.")


class PhoneTeleop:
    def __init__(self, kin: SO101Kinematics, robot, *, scale: float = 1.0, max_speed: float = 45.0,
                 roll_sign: float = 1.0, invert_gripper: bool = False, log_path: Path | None = None,
                 smooth: bool | None = None) -> None:
        self.kin, self.robot = kin, robot
        self.scale, self.max_speed, self.roll_sign, self.invert_gripper = scale, max_speed, roll_sign, invert_gripper
        self.q_cmd = np.radians(SEED_DEG)
        self.basis: np.ndarray | None = None
        self.anchor: dict | None = None
        self.last_ctrl: float | None = None
        self.last_fine = False
        self.last_time = time.monotonic()
        self.unreachable = 0
        self.grip_cmd = 50.0
        self.engaged = False
        self.last_action: dict | None = None  # most recent commanded action (read by the recorder)
        self.log_path = log_path
        self._last_print = 0.0
        self.smooth = SMOOTH_DEFAULT if smooth is None else smooth
        self.f_pos, self.f_rot = OneEuro(*SMOOTH_POS), OneEuro(*SMOOTH_ROT)
        self._last_ts: float | None = None
        self._last_out: tuple[np.ndarray, np.ndarray] | None = None
        if self.robot is not None:
            self._sync_from_robot()

    # ---- state
    def observe(self) -> tuple[np.ndarray, float] | None:
        if self.robot is None:
            return None
        obs = self.robot.get_observation()
        return np.array([obs[f"{n}.pos"] for n in ARM_JOINTS], dtype=float), float(obs["gripper.pos"])

    def _sync_from_robot(self) -> None:
        observed = self.observe()
        if observed is not None:
            self.q_cmd = np.radians(observed[0])
            self.grip_cmd = observed[1]

    def grip_for_app(self) -> float:
        return 100.0 - self.grip_cmd if self.invert_gripper else self.grip_cmd

    def current_action(self) -> dict:
        action = {f"{n}.pos": float(np.degrees(v)) for n, v in zip(ARM_JOINTS, self.q_cmd)}
        action["gripper.pos"] = float(self.grip_cmd)
        return action

    # ---- phone calibration
    def calibrate(self, pose: dict) -> None:
        validate_pose(pose)
        rot = quat_to_rot(pose["rotation"])
        forward = -rot[:, 2]  # ARCore camera looks down -Z
        forward = np.array([forward[0], 0.0, forward[2]])
        if np.linalg.norm(forward) < 0.3:
            raise ValueError("Hold the phone with the back camera facing forward, not at the floor or ceiling, then press Calibrate.")
        forward /= np.linalg.norm(forward)
        up = np.array([0.0, 1.0, 0.0])
        right = np.cross(forward, up)
        self.basis = np.stack([forward, -right, up])
        self.last_ctrl = None

    # ---- control
    def _reset_filters(self) -> None:
        self.f_pos.reset()
        self.f_rot.reset()
        self._last_ts = None
        self._last_out = None

    def _smooth(self, pose: dict, dt: float, delta: np.ndarray, rv: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        if not self.smooth:
            return delta, rv
        # Filter on every output tick, not only on new phone frames, so the pose stream is
        # interpolated into smooth targets instead of stair-steps held between frames.
        self._last_out = (self.f_pos(delta, dt), self.f_rot(rv, dt))
        return self._last_out

    def release(self) -> None:
        """Pad released / link lost: stop issuing targets. The servos hold the last position."""
        self._reset_filters()
        self.engaged = False
        self.last_ctrl = None
        self.anchor = None

    def engage(self, pose: dict, fine: bool) -> None:
        self._sync_from_robot()
        tip, pitch = self.kin.fk(self.q_cmd)
        self.anchor = {
            "t": np.array([pose["position"][k] for k in "xyz"], dtype=float),
            "R": quat_to_rot(pose["rotation"]),
            "tip": tip, "pitch": pitch, "roll": float(self.q_cmd[4]),
        }
        self.last_fine = fine
        self._reset_filters()
        self.engaged = True

    def control(self, pose: dict, fine: bool, gripper: float | None) -> dict:
        validate_pose(pose)
        now = time.monotonic()
        dt = min(max(now - self.last_time, 0.005), 0.1)
        self.last_time = now
        if self.basis is None:
            raise ValueError("Press Calibrate first.")
        if self.last_ctrl is None or now - self.last_ctrl > ENGAGE_GAP_S or fine != self.last_fine or self.anchor is None:
            self.engage(pose, fine)
        self.last_ctrl = now
        a = self.anchor
        scale = self.scale * (0.35 if fine else 1.0)

        delta_world = np.array([pose["position"][k] for k in "xyz"], dtype=float) - a["t"]
        rv = self.basis @ rotvec(quat_to_rot(pose["rotation"]) @ a["R"].T)
        delta_world, rv = self._smooth(pose, dt, delta_world, rv)
        tip_goal = a["tip"] + self.basis @ delta_world * scale
        pitch_goal = a["pitch"] - rv[1]
        roll_goal = float(np.clip(a["roll"] + self.roll_sign * rv[0], self.kin.low[4], self.kin.high[4]))

        q_seed = self.q_cmd.copy()
        q_seed[4] = roll_goal
        q_new, err = self.kin.ik(tip_goal, pitch_goal, q_seed)
        if err > 0.01 or not np.all(np.isfinite(q_new)):  # outside the workspace: hold instead of straining
            self.unreachable += 1
            q_new = self.q_cmd.copy()
            q_new[4] = roll_goal

        max_step = np.radians(self.max_speed) * dt
        self.q_cmd = np.clip(self.q_cmd + np.clip(q_new - self.q_cmd, -max_step, max_step), self.kin.low, self.kin.high)

        if gripper is not None:
            target = float(np.clip((gripper + 1) / 2, 0, 1))
            if self.invert_gripper:
                target = 1 - target
            self.grip_cmd += float(np.clip(target * 100.0 - self.grip_cmd, -200.0 * dt, 200.0 * dt))
        action = self.current_action()
        self.last_action = action
        if self.robot is not None:
            self.robot.send_action(action)
        elif now - self._last_print > 0.2:  # dry run: print at ~5 Hz instead of every message
            self._last_print = now
            print("DRY RUN", {k.replace(".pos", ""): round(v, 1) for k, v in action.items()}, "reach_err_mm", round(err * 1000, 1))
        return action
