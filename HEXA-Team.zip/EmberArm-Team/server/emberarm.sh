#!/usr/bin/env bash
# macOS / Ubuntu / Jetson launcher. First run creates a virtualenv; then:  ./emberarm.sh start --sim
set -e
cd "$(dirname "$0")"
PY="${PYTHON:-python3}"
if [ ! -d .venv ]; then
  "$PY" -m venv .venv
  .venv/bin/python -m pip install --upgrade pip -q
  .venv/bin/python -m pip install -r requirements.txt
fi
exec .venv/bin/python -m emberarm "$@"
