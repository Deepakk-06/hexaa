HEXA / EmberArm setup (Windows PC + phone)

Files in this zip: EmberArm-Final.apk (Android), PhoneTeleop.ipa (iPhone), server/ (runs on the PC)

1. PC (Windows 11), PowerShell as Administrator:
   wsl --install -d Ubuntu      (restart the PC, create a Linux user)
   Set-Content "$env:USERPROFILE\.wslconfig" "[wsl2]`nnetworkingMode=mirrored"
   wsl --shutdown
   New-NetFirewallRule -DisplayName HEXA -Direction Inbound -Protocol TCP -LocalPort 4443,8080 -Action Allow
   Set-NetFirewallHyperVVMSetting -Name '{40E0AC32-46A5-438A-A0B2-2B479E8F2E90}' -DefaultInboundAction Allow

2. Put HEXA-Team.zip in Downloads, open Ubuntu, run:
   sudo apt update && sudo apt install -y unzip python3-venv python3-pip && unzip -oq "$(ls /mnt/c/Users/*/Downloads/HEXA-Team.zip | head -1)" -d ~ && cd ~/EmberArm-Team/server && chmod +x emberarm.sh && ./emberarm.sh setup && ./emberarm.sh record --sim --max-speed 150

3. Terminal prints "In the phone app enter: ws://...". Phone must be on the same Wi-Fi as the PC.
   Open HEXA on the phone, type that ws:// address, Start tracking, Calibrate, hold the pad.
   Viewer: http://localhost:8080

Next time, only run: cd ~/EmberArm-Team/server && ./emberarm.sh record --sim --max-speed 150

Android: install EmberArm-Final.apk (allow Install unknown apps).
iPhone: install PhoneTeleop.ipa with Sideloadly (sideloadly.io). Install iTunes and iCloud from apple.com, not the Microsoft Store. Re-sign every 7 days.
