import React, {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import {
  Alert,
  Animated,
  Image,
  KeyboardAvoidingView,
  NativeEventEmitter,
  NativeModules,
  PanResponder,
  Platform,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
  requireNativeComponent,
  useWindowDimensions,
} from 'react-native';
import type {TextProps, ViewProps} from 'react-native';
import {SafeAreaProvider, SafeAreaView} from 'react-native-safe-area-context';

/* ----------------------------- Types & constants ----------------------------- */

type Pose = {
  position: {x: number; y: number; z: number};
  rotation: {x: number; y: number; z: number; w: number};
  tracking: 'normal' | 'initializing' | 'unavailable';
  timestamp: number;
};
type Imu = {
  acceleration: {x: number; y: number; z: number};
  angularVelocity: {x: number; y: number; z: number};
  orientation: {x: number; y: number; z: number; w: number};
  hasAcceleration: boolean;
  hasGyroscope: boolean;
  hasOrientation: boolean;
  timestamp: number;
};
type TeleopMessage =
  | {type: 'hello'; protocol: 1; client: 'emberarm-android'}
  | {type: 'discover'}
  | {type: 'calibrate'; pose: Pose}
  | {type: 'control'; pose: Pose; deadman: boolean; fine: boolean; gripper: number | null};
type Hardware = {armPort: string | null; cameras: number[]; motorEnabled: boolean; mode?: 'live' | 'sim' | 'dry'};
type Tone = 'good' | 'warn' | 'off';

const DevicePoseSurface = requireNativeComponent<ViewProps>('DevicePoseSurface');

const poseModule = NativeModules.DevicePose;
const poseEvents = poseModule ? new NativeEventEmitter(poseModule) : undefined;
const endpointExample = 'ws://192.168.1.100:4443/ws';

/** ARCore can hand over junk for a frame (NaN, huge values, broken quaternion). Never let that reach the screen or the arm. */
function isSanePose(pose: Pose): boolean {
  const {position: p, rotation: r} = pose;
  const values = [p.x, p.y, p.z, r.x, r.y, r.z, r.w];
  if (!values.every(Number.isFinite)) return false;
  if (Math.abs(p.x) > 100 || Math.abs(p.y) > 100 || Math.abs(p.z) > 100) return false; // metres from where tracking started
  const norm = Math.hypot(r.x, r.y, r.z, r.w);
  return norm > 0.9 && norm < 1.1;
}

const C = {
  bg: '#FFFDFC', card: 'rgba(255,255,255,0.86)', line: '#EEE7E1', ink: '#211914',
  sub: '#776C64', mute: '#AAA099', accent: '#F26322', accentSoft: '#FFF1E9',
  good: '#2E9958', goodSoft: '#EAF7EF', warn: '#B87921', warnSoft: '#FFF5DF',
  off: '#C8BFB7', disabled: '#F4EFEB',
};

/** Text that never grows past 120% so big system fonts can't break the layout. */
function T(props: TextProps) {
  return <Text maxFontSizeMultiplier={1.2} {...props} />;
}

/* -------------------------------- Small pieces -------------------------------- */

function toneColor(tone: Tone) {
  return tone === 'good' ? C.good : tone === 'warn' ? C.warn : C.off;
}

function Chip({label, tone}: {label: string; tone: Tone}) {
  return (
    <View style={styles.chip}>
      <View style={[styles.dot, {backgroundColor: toneColor(tone)}]} />
      <T numberOfLines={1} style={styles.chipText}>{label}</T>
    </View>
  );
}

function Shimmer({active}: {active: boolean}) {
  const sweep = useRef(new Animated.Value(-120)).current;

  useEffect(() => {
    if (!active) {
      sweep.stopAnimation();
      sweep.setValue(-120);
      return;
    }
    const animation = Animated.loop(
      Animated.sequence([
        Animated.timing(sweep, {toValue: 360, duration: 1650, useNativeDriver: true}),
        Animated.delay(1050),
        Animated.timing(sweep, {toValue: -120, duration: 0, useNativeDriver: true}),
      ]),
    );
    animation.start();
    return () => animation.stop();
  }, [active, sweep]);

  return <Animated.View pointerEvents="none" style={[styles.shimmer, {transform: [{translateX: sweep}, {rotate: '-18deg'}]}]} />;
}

function AxisReadout({axis, value}: {axis: 'X' | 'Y' | 'Z'; value: number | null}) {
  const valid = value !== null && Number.isFinite(value) && Math.abs(value) < 10000; // beyond 10 m the reading is not real
  const formatted = !valid ? '--' : `${value >= 0 ? '+' : '\u2212'}${Math.abs(value).toFixed(Math.abs(value) < 1000 ? 1 : 0)}`;
  return (
    <View style={styles.axisReadout}>
      <T style={styles.axisLabel}>{axis}</T>
      <T adjustsFontSizeToFit minimumFontScale={0.6} numberOfLines={1} style={styles.axisValue}>{formatted}</T>
      <T style={styles.axisUnit}>mm</T>
    </View>
  );
}

function DKMark() {
  const glow = useRef(new Animated.Value(0)).current;
  const sweep = useRef(new Animated.Value(-40)).current;

  useEffect(() => {
    const breathe = Animated.loop(
      Animated.sequence([
        Animated.timing(glow, {toValue: 1, duration: 1600, useNativeDriver: true}),
        Animated.timing(glow, {toValue: 0, duration: 1600, useNativeDriver: true}),
      ]),
    );
    const shimmer = Animated.loop(
      Animated.sequence([
        Animated.delay(900),
        Animated.timing(sweep, {toValue: 90, duration: 1000, useNativeDriver: true}),
        Animated.delay(1600),
        Animated.timing(sweep, {toValue: -40, duration: 0, useNativeDriver: true}),
      ]),
    );
    breathe.start();
    shimmer.start();
    return () => {
      breathe.stop();
      shimmer.stop();
    };
  }, [glow, sweep]);

  return (
    <View accessibilityLabel="DK" style={styles.dkWrap}>
      <Animated.View
        pointerEvents="none"
        style={[
          styles.dkHalo,
          {
            opacity: glow.interpolate({inputRange: [0, 1], outputRange: [0.12, 0.34]}),
            transform: [{scale: glow.interpolate({inputRange: [0, 1], outputRange: [1, 1.14]})}],
          },
        ]}
      />
      <View style={styles.dkTile}>
        <Image resizeMode="cover" source={require('./assets/dk-mark.png')} style={styles.dkImage} />
        <Animated.View pointerEvents="none" style={[styles.dkShineGroup, {transform: [{translateX: sweep}, {rotate: '20deg'}]}]}>
          <View style={styles.dkShineSoft} />
          <View style={styles.dkShineMid} />
          <View style={styles.dkShineCore} />
          <View style={styles.dkShineMid} />
          <View style={styles.dkShineSoft} />
        </Animated.View>
      </View>
    </View>
  );
}

function Signature() {
  return (
    <View style={styles.signature}>
      <DKMark />
      <T style={styles.credit}>Built by Deepak</T>
    </View>
  );
}

/* ----------------------------------- Screen ----------------------------------- */

function App() {

  const [endpoint, setEndpoint] = useState(endpointExample);
  const [connected, setConnected] = useState(false);
  const [serverReady, setServerReady] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [hardware, setHardware] = useState<Hardware>({armPort: null, cameras: [], motorEnabled: false, mode: undefined});
  const [tracking, setTracking] = useState<'idle' | Pose['tracking']>('idle');
  const [isCalibrated, setIsCalibrated] = useState(false);
  const stableSinceRef = useRef<number | null>(null);
  const [isPressed, setIsPressed] = useState(false);
  const [fineMode, setFineMode] = useState(false);
  const [gripper, setGripper] = useState<number | null>(null);
  const [livePose, setLivePose] = useState<Pose | null>(null);
  const [imu, setImu] = useState<Imu | null>(null);
  const [neutralPose, setNeutralPose] = useState<Pose | null>(null);
  const [demoMode, setDemoMode] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [showSensors, setShowSensors] = useState(false);
  const {height: windowHeight} = useWindowDimensions();

  const poseRef = useRef<Pose | null>(null);
  const socketRef = useRef<WebSocket | null>(null);
  const pressedRef = useRef(false);
  const fineRef = useRef(false);
  const gripperRef = useRef<number | null>(null); // value to send; null = leave the gripper alone
  const gripperBaseRef = useRef(0);
  const gripperLastRef = useRef(0); // last gripper value reported by the server
  const padWidthRef = useRef(0);
  const uiTickRef = useRef({pose: 0, imu: 0, grip: 0}); // throttles React re-renders
  const controlReadyRef = useRef(false);
  const setupScrollRef = useRef<React.ComponentRef<typeof ScrollView> | null>(null);

  const clearControl = useCallback(() => {
    pressedRef.current = false;
    gripperRef.current = null;
    setIsPressed(false);
  }, []);

  useEffect(() => {
    if (!poseEvents) return;
    const poseSubscription = poseEvents.addListener('devicePose', (event: unknown) => {
      const pose = event as Pose;
      if (!isSanePose(pose)) {
        poseRef.current = null;
        clearControl();
        setLivePose(null);
        setTracking('initializing');
        return;
      }
      poseRef.current = pose; // control loop always uses the newest pose
      if (!isCalibrated) {
        if (stableSinceRef.current === null) stableSinceRef.current = Date.now();
        if (Date.now() - stableSinceRef.current > 1200 && socketRef.current?.readyState === WebSocket.OPEN) {
          socketRef.current.send(JSON.stringify({type: 'calibrate', pose}));
          setNeutralPose(pose);
          setIsCalibrated(true);
        }
      }
      const nowPose = Date.now();
      if (nowPose - uiTickRef.current.pose > 100) { uiTickRef.current.pose = nowPose; setLivePose(pose); }
      setTracking('normal');
    });
    const imuSubscription = poseEvents.addListener('deviceImu', (event: unknown) => {
      const nowImu = Date.now();
      if (nowImu - uiTickRef.current.imu > 250) { uiTickRef.current.imu = nowImu; setImu(event as Imu); }
    });
    const trackingSubscription = poseEvents.addListener(
      'deviceTrackingState',
      (event: unknown) => {
        const state = String(event);
        if (state === 'initializing' || state === 'unavailable') {
          poseRef.current = null;
          setLivePose(null);
          clearControl();
          setTracking(state);
        }
      },
    );
    return () => {
      poseSubscription.remove();
      imuSubscription.remove();
      trackingSubscription.remove();
    };
  }, [clearControl, isCalibrated]);

  const send = useCallback((message: TeleopMessage) => {
    if (socketRef.current?.readyState === WebSocket.OPEN) socketRef.current.send(JSON.stringify(message));
  }, []);

  const connect = useCallback(() => {
    const url = endpoint.trim();
    if (!/^wss?:\/\/[^\s/]+(?::\d+)?(?:\/.*)?$/i.test(url)) {
      Alert.alert('Invalid server address', `Enter the address the server printed, for example ${endpointExample}`);
      return;
    }
    socketRef.current?.close();
    setDemoMode(false);
    setPreviewOpen(false);
    setConnecting(true);
    setConnected(false);
    setServerReady(false);
    setIsCalibrated(false);
    stableSinceRef.current = null;
    const socket = new WebSocket(url);
    socketRef.current = socket;
    let heartbeatTimer: ReturnType<typeof setInterval> | undefined;
    socket.onopen = () => {
      if (socketRef.current !== socket) return;
      setConnected(true);
      socket.send(JSON.stringify({type: 'hello', protocol: 1, client: 'emberarm-android'}));
      socket.send(JSON.stringify({type: 'discover'}));
      heartbeatTimer = setInterval(() => { if (socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify({type: 'heartbeat'})); }, 1000);
    };
    socket.onmessage = event => {
      if (socketRef.current !== socket) return;
      try {
        const message = JSON.parse(event.data);
        if (message.type === 'ready') {
          setServerReady(true);
          setConnecting(false);
        }
        if (message.type === 'state' && typeof message.gripper === 'number') {
          const value = Math.max(-1, Math.min(1, message.gripper / 50 - 1));
          gripperLastRef.current = value;
          if (gripperRef.current === null) setGripper(value);
        }
        if (message.type === 'hardware') {
          setHardware({
            armPort: message.arm_port ?? null,
            cameras: Array.isArray(message.cameras) ? message.cameras : [],
            motorEnabled: Boolean(message.motor_enabled),
            mode: message.mode,
          });
        }
        if (message.type === 'error') Alert.alert('Server error', String(message.message ?? 'Something went wrong on the server.'));
      } catch {
        /* Ignore non-protocol diagnostics. */
      }
    };
    socket.onclose = () => {
      if (heartbeatTimer !== undefined) clearInterval(heartbeatTimer);
      if (socketRef.current !== socket) return;
      clearControl();
      setConnecting(false);
      setConnected(false);
      setServerReady(false);
      setIsCalibrated(false);
      stableSinceRef.current = null;
    };
    socket.onerror = () => {
      if (heartbeatTimer !== undefined) clearInterval(heartbeatTimer);
      if (socketRef.current === socket) {
        setConnecting(false);
        Alert.alert('Could not connect', 'Check that the server is running, that your phone and computer are on the same Wi-Fi, and that the address is correct.');
      }
    };
  }, [clearControl, endpoint]);

  const startTracking = useCallback(async () => {
    if (!poseModule) {
      Alert.alert('AR tracking is unavailable', 'This app needs a physical Android phone that supports ARCore.');
      return;
    }
    try {
      await poseModule.start();
    } catch (error) {
      Alert.alert('Could not start AR tracking', String(error));
    }
  }, []);

  const calibrate = useCallback(() => {
    if (!poseRef.current || poseRef.current.tracking !== 'normal') {
      Alert.alert('Tracking is not ready', 'Wait until tracking says Ready, then try again.');
      return;
    }
    send({type: 'calibrate', pose: poseRef.current});
    setNeutralPose(poseRef.current);
    setIsCalibrated(true);
  }, [send]);

  useEffect(() => {
    const timer = setInterval(() => {
      if (isCalibrated && poseRef.current && poseRef.current.tracking === 'normal' && pressedRef.current) {
        send({type: 'control', pose: poseRef.current, deadman: true, fine: fineRef.current, gripper: gripperRef.current});
      }
    }, 50);
    return () => clearInterval(timer);
  }, [isCalibrated, send]);

  useEffect(
    () => () => {
      clearControl();
      socketRef.current?.close();
      poseModule?.stopTracking?.();
    },
    [clearControl],
  );

  // Preview is a safe local control surface and never sends without a socket.
  const controlReady = demoMode || (connected && serverReady && tracking === 'normal');
  controlReadyRef.current = controlReady;

  // Stable responder (reads refs) so it is never recreated in the middle of a gesture.
  const padResponder = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => controlReadyRef.current,
        onMoveShouldSetPanResponder: () => controlReadyRef.current,
        onPanResponderTerminationRequest: () => false, // don't let the ScrollView steal the drag
        onPanResponderGrant: event => {
          pressedRef.current = true;
          gripperRef.current = null;
          gripperBaseRef.current = gripperLastRef.current;
          setIsPressed(true);
          const fine = event.nativeEvent.locationX < padWidthRef.current / 2;
          fineRef.current = fine;
          setFineMode(fine);
        },
        onPanResponderMove: (_event, gesture) => {
          if (gripperRef.current === null && Math.abs(gesture.dy) < 10) return; // small dead zone
          const next = Math.max(-1, Math.min(1, gripperBaseRef.current - gesture.dy / 120));
          gripperRef.current = next;
          const nowGrip = Date.now();
          if (nowGrip - uiTickRef.current.grip > 60) { uiTickRef.current.grip = nowGrip; setGripper(next); }
        },
        onPanResponderRelease: clearControl,
        onPanResponderTerminate: clearControl,
      }),
    [clearControl],
  );

  /* ------------------------------- Derived state ------------------------------- */

  // Two setup steps: connect, then capture a stable starting pose automatically.
  const linked = connected && serverReady;
  const stage = !linked ? 0 : !isCalibrated ? 1 : 2;
  const modeLabel = demoMode ? 'PREVIEW' : !linked ? 'WAITING' : hardware.mode === 'sim' ? 'SIMULATION' : hardware.motorEnabled ? 'READY' : 'TEST';
  const trackingTone: Tone = tracking === 'normal' ? 'good' : tracking === 'initializing' ? 'warn' : 'off';
  const trackingText = tracking === 'normal' ? 'Ready' : tracking === 'initializing' ? 'Initializing. Move slowly toward a well-lit, textured area' : tracking === 'unavailable' ? 'Tracking unavailable' : 'Not started';
  const gripPercent = Math.round((((gripper ?? -1) + 1) / 2) * 100);
  const positionDelta = livePose && neutralPose && tracking === 'normal'
    ? {
        x: (livePose.position.x - neutralPose.position.x) * 1000,
        y: (livePose.position.y - neutralPose.position.y) * 1000,
        z: (livePose.position.z - neutralPose.position.z) * 1000,
      }
    : null;
  const displayedPosition = demoMode ? {x: 12.4, y: -6.8, z: 24.1} : positionDelta;

  const steps = [
    {
      title: 'Ready when you are',
      text: 'Enter the robot host address to begin. Keep your phone and follower arm on the same network.',
      button: connecting ? 'Connecting…' : 'Connect',
      onPress: connect,
      disabled: connecting,
    },
    {
      title: 'Set your frame',
      text: 'Move the phone slowly over a textured surface. HEXA captures your starting frame automatically.',
      button: 'Start tracking',
      onPress: startTracking,
      disabled: false,
    },
  ];

  /* ---------------------------------- Render ---------------------------------- */

  const modeTone = demoMode ? {bg: C.accentSoft, fg: C.accent} : !linked ? {bg: C.disabled, fg: C.sub} : hardware.motorEnabled ? {bg: C.goodSoft, fg: C.good} : {bg: C.warnSoft, fg: C.warn};
  // The pad scales with the screen so it is never squeezed on small phones or oversized on tall ones.
  const padHeight = Math.round(Math.min(300, Math.max(190, windowHeight * 0.3)));

  const progress = (
    <View style={styles.progress}>
      {[0, 1].map(i => (
        <View key={i} style={[styles.segment, stage > i && styles.segmentDone, stage === i && styles.segmentActive]} />
      ))}
    </View>
  );

  const sensorGroups = [
    {title: 'ACCELEROMETER · m/s²', ok: imu?.hasAcceleration, data: imu?.acceleration, axes: ['x', 'y', 'z'] as const, digits: 2},
    {title: 'GYROSCOPE · rad/s', ok: imu?.hasGyroscope, data: imu?.angularVelocity, axes: ['x', 'y', 'z'] as const, digits: 3},
    {title: 'ORIENTATION · QUATERNION', ok: imu?.hasOrientation, data: imu?.orientation, axes: ['x', 'y', 'z', 'w'] as const, digits: 3},
  ];

  return (
    <SafeAreaProvider>
      <StatusBar barStyle="dark-content" />
      {Platform.OS === 'android' ? (
        <DevicePoseSurface pointerEvents="none" collapsable={false} style={StyleSheet.absoluteFill} />
      ) : null}
      <SafeAreaView style={styles.screen} edges={['top', 'bottom', 'left', 'right']}>
        <KeyboardAvoidingView behavior="padding" style={styles.keyboardSafe}>
          <View style={styles.page}>
            <View style={styles.header}>
              <View style={styles.brandGroup}>
                <View style={styles.logo}><View style={styles.logoDot} /></View>
                <View style={styles.brandCopy}>
                  <T style={styles.brand}>HEXA</T>
                  <T numberOfLines={1} ellipsizeMode="tail" style={styles.brandCaption}>PHONE LEADER · SO-101 FOLLOWER</T>
                </View>
              </View>
              <View style={[styles.headerPill, {backgroundColor: modeTone.bg}]}>
                <View style={[styles.dot, {backgroundColor: modeTone.fg}]} />
                <T style={[styles.pillText, {color: modeTone.fg}]}>{modeLabel}</T>
              </View>
            </View>
            {stage < 2 && !previewOpen ? (
              <ScrollView
                ref={setupScrollRef}
                contentContainerStyle={styles.setup}
                keyboardDismissMode="on-drag"
                keyboardShouldPersistTaps="handled"
                showsVerticalScrollIndicator={false}>
                <T style={styles.eyebrow}>{stage === 0 ? 'PHONE LEADER' : 'FOLLOWER ARM'}</T>
                <T style={styles.heading}>{stage === 0 ? 'Move with intent.' : 'Find your frame.'}</T>
                <T style={styles.body}>{steps[stage].text}</T>

                {stage === 0 ? (
                  <View style={styles.field}>
                    <T style={styles.label}>HOST</T>
                    <TextInput
                      autoCapitalize="none"
                      autoCorrect={false}
                      keyboardType="url"
                      maxFontSizeMultiplier={1.2}
                      onChangeText={setEndpoint}
                      onFocus={() => requestAnimationFrame(() => setupScrollRef.current?.scrollToEnd({animated: true}))}
                      placeholder={endpointExample}
                      placeholderTextColor={C.mute}
                      selectionColor={C.accent}
                      style={styles.input}
                      value={endpoint}
                    />
                  </View>
                ) : null}

                {stage === 1 ? (
                  <View style={styles.trackingBox}>
                    <View style={[styles.dotLg, {backgroundColor: toneColor(trackingTone)}]} />
                    <T style={styles.trackingText}>Tracking: {trackingText}</T>
                  </View>
                ) : null}

                <View style={styles.spacer} />
                <Pressable
                  accessibilityRole="button"
                  disabled={steps[stage].disabled}
                  onPress={steps[stage].onPress}
                  style={({pressed}) => [styles.button, steps[stage].disabled && styles.buttonOff, pressed && styles.pressed]}>
                  <T style={[styles.buttonText, steps[stage].disabled && {color: C.mute}]}>{steps[stage].button}</T>
                </Pressable>
                {stage === 0 ? (
                  <Pressable accessibilityRole="button" onPress={() => { setDemoMode(true); setPreviewOpen(true); }} style={styles.previewBtn}>
                    <T style={styles.link}>Preview the controls</T>
                  </Pressable>
                ) : null}
              </ScrollView>
            ) : (
              <ScrollView
                contentContainerStyle={styles.control}
                scrollEnabled={!isPressed}
                showsVerticalScrollIndicator={false}>
                <View style={styles.statusLine}>
                  <View style={[styles.dotLg, {backgroundColor: controlReady ? C.good : C.warn}]} />
                  <T style={styles.statusText}>{demoMode ? 'Preview controls' : controlReady ? 'Ready to move' : !linked ? 'Waiting for the host' : 'Tracking is settling'}</T>
                </View>

                <View style={styles.chips}>
                  <Chip label={hardware.armPort ? 'Arm detected' : 'No arm detected'} tone={hardware.armPort ? 'good' : 'off'} />
                  <Chip label={hardware.motorEnabled ? 'Arm live' : 'Dry run'} tone={hardware.motorEnabled ? 'good' : 'off'} />
                </View>

                <View style={styles.card}>
                  <View style={styles.cardHeader}>
                    <View style={styles.titleRow}>
                      <View style={[styles.dot, {backgroundColor: controlReady || demoMode ? C.accent : C.off}]} />
                      <T style={styles.caption}>{demoMode ? 'PREVIEW POSITION' : 'LIVE POSITION'}</T>
                    </View>
                    <T style={styles.captionMute}>{demoMode ? 'SAMPLE' : 'SINCE START'}</T>
                  </View>
                  <View style={styles.axisRow}>
                    <AxisReadout axis="X" value={displayedPosition?.x ?? null} />
                    <AxisReadout axis="Y" value={displayedPosition?.y ?? null} />
                    <AxisReadout axis="Z" value={displayedPosition?.z ?? null} />
                  </View>
                </View>

                <View style={styles.padGroup}>
                  <View
                    accessibilityLabel="Hold to move control pad"
                    onLayout={event => {
                      padWidthRef.current = event.nativeEvent.layout.width;
                    }}
                    style={[styles.pad, {height: padHeight}, !controlReady && styles.padOff]}
                    {...padResponder.panHandlers}>
                    <View pointerEvents="none" style={[styles.zone, isPressed && (fineMode ? styles.zoneOn : styles.zoneDim)]}>
                      <T style={[styles.zoneTitle, isPressed && fineMode && {color: '#FFFFFF'}]}>Fine</T>
                    </View>
                    <View pointerEvents="none" style={styles.zoneDivider} />
                    <View pointerEvents="none" style={[styles.zone, isPressed && (!fineMode ? styles.zoneOn : styles.zoneDim)]}>
                      <T style={[styles.zoneTitle, isPressed && !fineMode && {color: '#FFFFFF'}]}>Normal</T>
                    </View>
                    <View pointerEvents="none" style={styles.padCenter}>
                      <T style={[styles.padState, !controlReady && {color: C.mute}, isPressed && {color: '#FFFFFF'}]}>
                        {isPressed ? 'Moving' : controlReady ? 'Hold to move' : 'Locked'}
                      </T>
                    </View>
                    <View pointerEvents="none" style={styles.meter}>
                      <View style={[styles.meterFill, {height: `${gripPercent}%`}]} />
                    </View>
                  </View>
                  <T style={styles.hint}>Left side: fine. Right side: normal. Slide up or down for the gripper.</T>
                </View>

                {!demoMode ? <View style={styles.card}>
                  <Pressable accessibilityRole="button" onPress={() => setShowSensors(v => !v)} style={styles.cardHeader}>
                    <View style={styles.titleRow}>
                      <View style={[styles.dot, {backgroundColor: imu ? C.good : C.off}]} />
                      <T style={styles.caption}>SENSORS</T>
                    </View>
                    <T style={styles.link}>{showSensors ? 'Hide' : 'Show'}</T>
                  </Pressable>
                  {showSensors ? (
                    <View>
                      {sensorGroups.map(group => (
                        <View key={group.title}>
                          <T style={styles.sectionTitle}>{group.title}</T>
                          <View style={styles.axisRow}>
                            {group.axes.map(axis => (
                              <View key={axis} style={styles.axisReadout}>
                                <T style={styles.axisLabel}>{axis.toUpperCase()}</T>
                                <T style={styles.sensorValue}>{group.ok && group.data ? (group.data as Record<string, number>)[axis].toFixed(group.digits) : '--'}</T>
                              </View>
                            ))}
                          </View>
                        </View>
                      ))}
                    </View>
                  ) : null}
                </View> : null}

                <View style={styles.safetyNote}>
                  <View style={styles.safetyIcon}><T style={styles.safetyIconText}>!</T></View>
                  <T style={styles.safetyText}>The arm only moves while you hold the pad. Let go to stop.</T>
                </View>

                <View style={styles.linksRow}>
                  <Pressable accessibilityRole="button" onPress={demoMode ? () => { setDemoMode(false); setPreviewOpen(false); } : connect} style={styles.linkBtn}>
                    <T style={styles.link}>{demoMode ? 'Close preview' : 'Reconnect'}</T>
                  </Pressable>
                  <Pressable accessibilityRole="button" onPress={demoMode ? () => { setDemoMode(false); setPreviewOpen(false); } : () => { setIsCalibrated(false); stableSinceRef.current = null; }} style={styles.linkBtn}>
                    <T style={styles.link}>{demoMode ? 'Done' : 'Set starting pose'}</T>
                  </Pressable>
                </View>
                <Signature />
              </ScrollView>
            )}
          </View>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

// Type scale (only these): 28 heading · 22 value · 17 title/button · 15 body · 13 label · 11 caption
const styles = StyleSheet.create({
  screen: {flex: 1, backgroundColor: C.bg},
  keyboardSafe: {flex: 1},
  page: {alignSelf: 'center', flex: 1, maxWidth: 520, paddingHorizontal: 22, paddingTop: 14, width: '100%'},

  header: {alignItems: 'center', flexDirection: 'row', gap: 12, justifyContent: 'space-between'},
  brandGroup: {alignItems: 'center', flex: 1, flexDirection: 'row', gap: 12, minWidth: 0},
  logo: {alignItems: 'center', backgroundColor: C.accentSoft, borderColor: '#FFD4BC', borderRadius: 15, borderWidth: 1, height: 46, justifyContent: 'center', width: 46},
  logoDot: {backgroundColor: C.accent, borderRadius: 4, height: 14, transform: [{rotate: '45deg'}], width: 14},
  brand: {color: C.ink, fontSize: 19, fontWeight: '800', letterSpacing: -0.6},
  headerPill: {alignItems: 'center', borderColor: C.line, borderRadius: 20, borderWidth: 1, flexDirection: 'row', gap: 6, paddingHorizontal: 11, paddingVertical: 7},
  pillText: {fontSize: 11, fontWeight: '700', letterSpacing: 0.8},

  progress: {flexDirection: 'row', gap: 6, marginTop: 16},
  segment: {backgroundColor: C.line, borderRadius: 2, flex: 1, height: 4},
  segmentDone: {backgroundColor: C.good},
  segmentActive: {backgroundColor: C.accent},

  brandCopy: {flex: 1, minWidth: 0},
  brandCaption: {color: C.sub, flexShrink: 1, fontSize: 10, fontWeight: '600', letterSpacing: 0.45, maxWidth: 170},
  caption: {color: C.sub, flexShrink: 1, fontSize: 10, fontWeight: '600', letterSpacing: 0.55},
  captionMute: {color: C.mute, fontSize: 11, fontWeight: '600', letterSpacing: 0.8},
  link: {color: C.accent, fontSize: 15, fontWeight: '600'},

  setup: {flexGrow: 1, paddingBottom: 10, paddingTop: 26},
  eyebrow: {color: C.accent, fontSize: 11, fontWeight: '800', letterSpacing: 1.8},
  heading: {color: C.ink, fontSize: 34, fontWeight: '800', letterSpacing: -1, lineHeight: 40, marginTop: 12},
  body: {color: C.sub, fontSize: 15, lineHeight: 22, marginTop: 12},
  field: {marginTop: 18},
  label: {color: C.sub, fontSize: 13, fontWeight: '600', marginBottom: 8},
  input: {backgroundColor: '#FFFFFF', borderColor: C.line, borderRadius: 16, borderWidth: 1, color: C.ink, fontSize: 15, minHeight: 56, paddingHorizontal: 16, shadowColor: '#D8C9BE', shadowOpacity: 0.16, shadowRadius: 18, shadowOffset: {width: 0, height: 8}},
  trackingBox: {alignItems: 'center', backgroundColor: C.card, borderColor: C.line, borderRadius: 18, borderWidth: 1, flexDirection: 'row', gap: 12, marginTop: 24, padding: 16, shadowColor: '#D8C9BE', shadowOpacity: 0.16, shadowRadius: 18, shadowOffset: {width: 0, height: 8}},
  trackingText: {color: C.ink, flexShrink: 1, fontSize: 15, fontWeight: '600', lineHeight: 22},
  spacer: {flex: 1, minHeight: 24},

  button: {alignItems: 'center', alignSelf: 'stretch', backgroundColor: C.accent, borderRadius: 18, justifyContent: 'center', minHeight: 58, paddingHorizontal: 16},
  buttonOff: {backgroundColor: C.disabled},
  buttonText: {color: '#FFFFFF', fontSize: 17, fontWeight: '600'},
  pressed: {opacity: 0.85},
  previewBtn: {alignItems: 'center', alignSelf: 'stretch', borderColor: C.line, borderRadius: 14, borderWidth: 1, justifyContent: 'center', marginTop: 8, minHeight: 44, paddingHorizontal: 12},


  signature: {alignItems: 'center', gap: 4, marginTop: 16},
  credit: {color: C.sub, fontSize: 11, fontWeight: '600', letterSpacing: 0.8},
  dkWrap: {alignItems: 'center', height: 68, justifyContent: 'center', width: 68},
  dkHalo: {backgroundColor: C.accent, borderRadius: 20, height: 60, position: 'absolute', width: 60},
  dkTile: {borderRadius: 14, height: 52, overflow: 'hidden', width: 52},
  dkImage: {height: '100%', width: '100%'},
  dkShineGroup: {alignItems: 'center', flexDirection: 'row', height: 90, left: 0, position: 'absolute', top: -18},
  dkShineSoft: {backgroundColor: 'rgba(255,200,160,0.07)', height: '100%', width: 9},
  dkShineMid: {backgroundColor: 'rgba(255,214,180,0.16)', height: '100%', width: 6},
  dkShineCore: {backgroundColor: 'rgba(255,240,225,0.40)', height: '100%', width: 3},

  // control screen scrolls, so nothing is ever clipped on a small phone; the pad is fixed-height and locks the scroll while held
  control: {flexGrow: 1, gap: 12, paddingBottom: 16, paddingTop: 20},
  statusLine: {alignItems: 'flex-start', flexDirection: 'row', gap: 10},
  statusText: {color: C.ink, flexShrink: 1, fontSize: 17, fontWeight: '600', lineHeight: 24},
  chips: {flexDirection: 'row', flexWrap: 'wrap', gap: 8},
  chip: {alignItems: 'center', backgroundColor: C.card, borderColor: C.line, borderRadius: 16, borderWidth: 1, flexDirection: 'row', gap: 6, paddingHorizontal: 12, paddingVertical: 7},
  chipText: {color: C.ink, fontSize: 13, fontWeight: '500'},
  dot: {borderRadius: 4, height: 8, width: 8},
  dotLg: {borderRadius: 6, height: 12, marginTop: 6, width: 12},

  card: {backgroundColor: C.card, borderColor: C.line, borderRadius: 20, borderWidth: 1, overflow: 'hidden', padding: 16, shadowColor: '#D8C9BE', shadowOpacity: 0.12, shadowRadius: 18, shadowOffset: {width: 0, height: 8}},
  cardHeader: {alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between', minHeight: 24},
  titleRow: {alignItems: 'center', flexDirection: 'row', gap: 8},
  axisRow: {flexDirection: 'row', marginTop: 14},
  axisReadout: {borderLeftColor: C.line, borderLeftWidth: 1, flex: 1, paddingLeft: 12},
  axisLabel: {color: C.mute, fontSize: 11, fontWeight: '600', letterSpacing: 0.8},
  axisValue: {color: C.ink, fontSize: 22, fontWeight: '700', letterSpacing: -0.4, marginTop: 4},
  axisUnit: {color: C.sub, fontSize: 11, fontWeight: '600', marginTop: 2},
  sectionTitle: {color: C.sub, fontSize: 11, fontWeight: '600', letterSpacing: 0.8, marginTop: 18},
  sensorValue: {color: C.ink, fontSize: 13, fontWeight: '600', marginTop: 4},

  padGroup: {gap: 10},
  pad: {backgroundColor: C.card, borderColor: C.line, borderRadius: 28, borderWidth: 1, flexDirection: 'row', overflow: 'hidden'},
  padOff: {backgroundColor: C.disabled},
  zone: {alignItems: 'center', flex: 1, paddingTop: 18},
  zoneOn: {backgroundColor: C.accent},
  zoneDim: {backgroundColor: C.disabled},
  zoneDivider: {backgroundColor: C.line, width: 1},
  zoneTitle: {color: C.sub, fontSize: 13, fontWeight: '600', letterSpacing: 0.4},
  padCenter: {alignItems: 'center', bottom: 0, justifyContent: 'center', left: 0, position: 'absolute', right: 0, top: 0},
  padState: {color: C.ink, fontSize: 22, fontWeight: '700', letterSpacing: -0.3},
  meter: {backgroundColor: C.line, borderRadius: 3, bottom: 16, position: 'absolute', right: 10, top: 16, width: 6},
  meterFill: {backgroundColor: C.ink, borderRadius: 3, bottom: 0, position: 'absolute', width: '100%'},
  hint: {color: C.sub, fontSize: 13, lineHeight: 18, textAlign: 'center'},

  safetyNote: {alignItems: 'center', backgroundColor: C.accentSoft, borderRadius: 14, flexDirection: 'row', gap: 10, paddingHorizontal: 14, paddingVertical: 12},
  safetyIcon: {alignItems: 'center', backgroundColor: C.accent, borderRadius: 10, height: 20, justifyContent: 'center', width: 20},
  safetyIconText: {color: '#FFFFFF', fontSize: 13, fontWeight: '700', lineHeight: 16},
  safetyText: {color: '#9A3A0B', flex: 1, fontSize: 13, fontWeight: '500', lineHeight: 18},

  linksRow: {flexDirection: 'row', justifyContent: 'space-between'},
  linkBtn: {justifyContent: 'center', minHeight: 44, paddingHorizontal: 4},
});

export default App;
