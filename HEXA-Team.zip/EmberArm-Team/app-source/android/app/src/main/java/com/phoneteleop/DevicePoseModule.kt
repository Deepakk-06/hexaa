package com.phoneteleop

import android.Manifest
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.content.pm.PackageManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.modules.core.DeviceEventManagerModule
import com.facebook.react.bridge.LifecycleEventListener
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Config
import com.google.ar.core.Session

class DevicePoseModule(private val reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext), LifecycleEventListener, SensorEventListener {

    @Volatile private var session: Session? = null
    @Volatile private var surface: DevicePoseSurfaceView? = null
    @Volatile private var trackingRequested = false
    @Volatile private var hostResumed = true

    private val sensorManager =
        reactContext.getSystemService(android.content.Context.SENSOR_SERVICE) as SensorManager

    private val acceleration = FloatArray(3)
    private val angularVelocity = FloatArray(3)
    private val orientation = floatArrayOf(1f, 0f, 0f, 0f)

    @Volatile private var hasAcceleration = false
    @Volatile private var hasGyroscope = false
    @Volatile private var hasOrientation = false

    private fun startImuSensors() {
        val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        val rotationVector = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

        if (accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME)
        }
        if (gyroscope != null) {
            sensorManager.registerListener(this, gyroscope, SensorManager.SENSOR_DELAY_GAME)
        }
        if (rotationVector != null) {
            sensorManager.registerListener(this, rotationVector, SensorManager.SENSOR_DELAY_GAME)
        }

        Log.i(TAG, "IMU sensors registered: accel=${accelerometer != null}, gyro=${gyroscope != null}, rotation=${rotationVector != null}")
    }

    private fun stopImuSensors() {
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> {
                System.arraycopy(event.values, 0, acceleration, 0, 3)
                hasAcceleration = true
            }
            Sensor.TYPE_GYROSCOPE -> {
                System.arraycopy(event.values, 0, angularVelocity, 0, 3)
                hasGyroscope = true
            }
            Sensor.TYPE_ROTATION_VECTOR -> {
                val quaternion = FloatArray(4)
                SensorManager.getQuaternionFromVector(quaternion, event.values)
                orientation[0] = quaternion[1]
                orientation[1] = quaternion[2]
                orientation[2] = quaternion[3]
                orientation[3] = quaternion[0]
                hasOrientation = true
            }
        }

        val message = Arguments.createMap().apply {
            putMap("acceleration", Arguments.createMap().apply {
                putDouble("x", acceleration[0].toDouble())
                putDouble("y", acceleration[1].toDouble())
                putDouble("z", acceleration[2].toDouble())
            })
            putMap("angularVelocity", Arguments.createMap().apply {
                putDouble("x", angularVelocity[0].toDouble())
                putDouble("y", angularVelocity[1].toDouble())
                putDouble("z", angularVelocity[2].toDouble())
            })
            putMap("orientation", Arguments.createMap().apply {
                putDouble("x", orientation[0].toDouble())
                putDouble("y", orientation[1].toDouble())
                putDouble("z", orientation[2].toDouble())
                putDouble("w", orientation[3].toDouble())
            })
            putBoolean("hasAcceleration", hasAcceleration)
            putBoolean("hasGyroscope", hasGyroscope)
            putBoolean("hasOrientation", hasOrientation)
            putDouble("timestamp", event.timestamp.toDouble())
        }

        reactContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
            .emit("deviceImu", message)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun getName() = "DevicePose"

    init {
        reactContext.addLifecycleEventListener(this)
    }

    @ReactMethod fun addListener(eventName: String) = Unit
    @ReactMethod fun removeListeners(count: Int) = Unit

    internal fun attachSurface(view: DevicePoseSurfaceView) {
        surface = view
        view.setArSession(session)
    }

    internal fun detachSurface(view: DevicePoseSurfaceView) {
        if (surface === view) {
            trackingRequested = false
            view.setArSession(null)
            surface = null
            stopSession()
        }
    }

    @ReactMethod
    fun start(promise: Promise) {
        val activity = reactContext.currentActivity
        if (activity == null) {
            promise.reject("NO_ACTIVITY", "Open the app before starting AR tracking.")
            return
        }

        if (surface == null) {
            promise.reject("NO_GL_SURFACE", "AR rendering surface is not attached. Reopen the app and try again.")
            return
        }

        if (ContextCompat.checkSelfPermission(reactContext, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {
            activity.runOnUiThread {
                activity.requestPermissions(arrayOf(Manifest.permission.CAMERA), CAMERA_REQUEST)
            }
            promise.reject("CAMERA_PERMISSION", "Grant camera permission, then tap START TRACKING again.")
            return
        }

        activity.runOnUiThread {
            try {
                if (ArCoreApk.getInstance().requestInstall(activity, true) ==
                    ArCoreApk.InstallStatus.INSTALL_REQUESTED) {
                    promise.reject("ARCORE_INSTALL", "Install or update Google Play Services for AR, then try again.")
                    return@runOnUiThread
                }

                var arSession = session
                if (arSession == null) {
                    arSession = Session(reactContext)
                    arSession.configure(Config(arSession).apply {
                        updateMode = Config.UpdateMode.LATEST_CAMERA_IMAGE
                    })
                    session = arSession
                }

                if (!hostResumed) {
                    promise.reject("APP_PAUSED", "Return to the app and start tracking again.")
                    return@runOnUiThread
                }

                trackingRequested = true
                emitTrackingState("initializing")
                @Suppress("DEPRECATION")
                val rotation = activity.windowManager.defaultDisplay.rotation
                surface?.setDisplayRotation(rotation)
                surface?.setArSession(arSession)
                arSession.resume()
                surface?.onResume()
                promise.resolve(null)
            } catch (error: Exception) {
                trackingRequested = false
                Log.e(TAG, "Could not start ARCore", error)
                promise.reject("ARCORE_ERROR", error.message, error)
            }
        }
    }

    @ReactMethod
    fun stop() {
        trackingRequested = false
        reactContext.runOnUiQueueThread { stopSession() }
    }

    private fun stopSession() {
        try {
            surface?.setArSession(null)
            session?.pause()
        } catch (error: Exception) {
            Log.w(TAG, "Error pausing ARCore", error)
        }
    }

    internal fun emitTrackingState(state: String) {
        if (!trackingRequested) return
        reactContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
            .emit("deviceTrackingState", state)
    }

    internal fun emitPose(position: FloatArray, rotation: FloatArray, tracking: String) {
        if (!trackingRequested) return

        val message = Arguments.createMap().apply {
            putMap("position", Arguments.createMap().apply {
                putDouble("x", position[0].toDouble())
                putDouble("y", position[1].toDouble())
                putDouble("z", position[2].toDouble())
            })
            putMap("rotation", Arguments.createMap().apply {
                putDouble("x", rotation[0].toDouble())
                putDouble("y", rotation[1].toDouble())
                putDouble("z", rotation[2].toDouble())
                putDouble("w", rotation[3].toDouble())
            })
            putString("tracking", tracking)
            putDouble("timestamp", System.currentTimeMillis().toDouble())
        }

        reactContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
            .emit("devicePose", message)
    }

    override fun onHostResume() {
        hostResumed = true
    }

    override fun onHostPause() {
        hostResumed = false
        trackingRequested = false
        reactContext.runOnUiQueueThread {
            try {
                surface?.onPause()
                session?.pause()
            } catch (error: Exception) {
                Log.e(TAG, "Could not pause ARCore", error)
            }
        }
    }

    override fun onHostDestroy() {
        trackingRequested = false
        reactContext.runOnUiQueueThread {
            try {
                surface?.onPause()
                session?.close()
                session = null
            } catch (error: Exception) {
                Log.e(TAG, "Could not close ARCore", error)
            }
        }
    }

    companion object {
        private const val TAG = "DevicePose"
        private const val CAMERA_REQUEST = 907
    }
}
