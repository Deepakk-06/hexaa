package com.phoneteleop

import com.facebook.react.uimanager.SimpleViewManager
import com.facebook.react.uimanager.ThemedReactContext

class DevicePoseSurfaceManager(private val poseModule: DevicePoseModule) :
    SimpleViewManager<DevicePoseSurfaceView>() {

    override fun getName() = "DevicePoseSurface"

    override fun createViewInstance(reactContext: ThemedReactContext): DevicePoseSurfaceView {
        return DevicePoseSurfaceView(reactContext, poseModule).also {
            poseModule.attachSurface(it)
        }
    }

    override fun onDropViewInstance(view: DevicePoseSurfaceView) {
        poseModule.detachSurface(view)
        super.onDropViewInstance(view)
    }
}
