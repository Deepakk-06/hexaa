# HEXA: use an Android phone as the leader arm for an SO-101 follower

The phone tracks its own position and tilt with ARCore and streams it over Wi-Fi to a Python server on your computer. The server turns that into SO-101 joint targets (inverse kinematics from the official URDF) and, with `--live`, moves the follower through LeRobot. No leader arm needed.

## 1. Build and install the app (Android phone, USB debugging on)

```bash
./build-apk.sh
```

This builds `EmberArm-Final.apk`, installs it on the connected phone and opens it. Share the APK file to install on other Android phones (they must support ARCore).

## 2. Run the host (Windows, macOS, Ubuntu / Jetson: same code)

The host is one Python package (`server/emberarm`). Any computer works; the phone only needs its IP address.

```bash
cd server
./emberarm.sh setup            # macOS / Linux   (Windows: emberarm.bat setup)
./emberarm.sh selftest         # URDF + IK check, no phone or arm needed
./emberarm.sh start            # dry run: prints joint targets, nothing moves
./emberarm.sh start --sim      # simulated arm, no hardware
```

Needs Python 3.10+. `setup` creates a virtualenv, installs the requirements and `lerobot[feetech]`
(add `--no-lerobot` to skip the large LeRobot install; dry run and simulation do not need it).
`./emberarm.sh doctor` shows what is installed and which arm ports are detected.

The host prints an address such as `ws://192.168.1.20:4443/ws`. Enter it in the app. Phone and computer must be on the same Wi-Fi.
The old v7 command `python3 teleop_server.py [--live]` still works.

| Command | What it does |
| --- | --- |
| `setup` | install dependencies, write `emberarm.json` |
| `doctor` | check dependencies and hardware |
| `discover [--cameras]` | list arm ports (COMx, /dev/ttyACM*, /dev/tty.usbmodem*) and cameras |
| `calibrate` | run LeRobot follower calibration on the detected port |
| `selftest` | check URDF and IK |
| `start [--sim\|--live]` | teleoperate |
| `record [--sim\|--live]` | teleoperate and record episodes |

## 3. Move the real arm

```bash
./emberarm.sh calibrate        # once per arm; move each joint through its range when LeRobot asks
./emberarm.sh start --live
```

The port is auto-detected. If more than one USB serial device is plugged in, pass `--arm-port COM3` (or `/dev/ttyACM0`).
Use `--id` if you calibrated under another robot id. If the wrist turns the wrong way add `--roll-sign -1`; if the gripper is inverted add `--invert-gripper`.
On Linux/Jetson you may need `sudo usermod -aG dialout $USER`, then log out and back in.

## 4. Record demonstrations

```bash
./emberarm.sh record --sim --task "pick up the cube"                       # no hardware
./emberarm.sh record --live --camera front=0 --task "pick up the cube"     # real arm + camera
```

While it runs, type in the terminal: `r` + Enter starts an episode, `r` again stops and saves it, `d` discards, `q` quits.
Frames are captured at a fixed rate (`--fps`, default 30) and saved to `server/datasets/emberarm_demo` as a LeRobotDataset
(`observation.state`, `action`, camera video, task). If LeRobot's dataset API cannot be loaded, the host says so and writes plain
`.npz` episodes instead so nothing is lost; they are not LeRobot format.
The app has no record button yet; the host also accepts `{"type":"record","action":"start|stop|discard"}` messages for adding one.

## Using the app

1. **Connect** to the host address.
2. **Start tracking** and move the phone slowly until it says Ready.
3. **Calibrate:** stand behind the robot, point the phone's back camera toward the front of the robot, and tap Calibrate.
4. **Hold the pad to move.** Hold the left side for slow, precise moves and the right side for normal speed. While holding, slide up or down to change the gripper. Let go to stop. Each new press starts from wherever the arm is, so it never jumps.

Phone movement maps to the gripper tip (forward, sideways, up). Tilting the phone up or down tilts the gripper, and twisting the phone around its camera axis rolls the wrist.

## Safety

- The arm only moves while you hold the pad and tracking is Ready; releasing the pad, losing Wi-Fi (3 s silence) or disconnecting stops new targets and the servos hold position.
- Joint speed is capped (`--max-speed`, default 45 deg/s), joints are clamped to the URDF limits, and LeRobot limits each step to 5 degrees.
- Malformed or non-finite poses from the phone are rejected. A second phone cannot take over a running session.
- Targets outside the arm's reach are ignored and the arm holds.
- When the host exits, LeRobot turns motor torque off and the arm goes limp. Support the arm before pressing `q`/Ctrl+C.
- This is still not a certified safety system. For first live tests keep your hand near the power supply and move slowly.

## Status of this version

Tested here: URDF/IK self-test and 9 unit tests (protocol handling through a fake socket, safety behaviour, port filtering, recording).
**Not tested here** (no hardware, no network): the real `websockets` server, a physical SO-101, USB cameras, the LeRobotDataset backend
against your installed LeRobot version, and the Windows launcher. LeRobot's API changes between releases, so run `record --sim` first and check the dataset loads.
Not built: ROS 2 bridge, training workflow, in-app record button.
